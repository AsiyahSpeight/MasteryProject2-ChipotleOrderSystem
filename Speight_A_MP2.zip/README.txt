README.txt file for CPSC-231 assignment MP2 at Chapman University 

AUTHOR INFO
Full name: Asiyah Speight 
Student ID: 2357167
Chapman Email: aspeight@chapman.edu 
Course number and section: CPSC-231-01
Assignment or exercise number: MP 2 - Chipotle Ordering System

ERRORS 
no errors

SOURCES
A list of all references used to complete the assignment, including peers (if applicable)
LLM ChatGPT, was used as a guide to ensure the code ran smoothly with no issues. Gemini was attempted, but didn't give the best results as ChatGPT did, therefore it was not referenced in my code as I did not use any of the suggestions it gave me. Lecture material was used as a guide, specifically the lecture on classes, as ThreadsAccount class that was built in class was used as a guide, the driver for the class, as well as the second class was built using the same class that was built in class. Professors office hours was also used, references came in the form of help.

